package com.teste.marvelkotlin.model

const val PUBLIC_KEY = "d57b2c4f97462d808b06cbdc4636e1f2"
const val PRIVATE_KEY = "47f6092de91974fc6c0555af229a5a8948c32098"