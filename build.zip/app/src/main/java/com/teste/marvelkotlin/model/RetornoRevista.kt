package com.teste.marvelkotlin.model

class RetornoRevista  (
    val code: Int,
    val etag: String,
    val data: DadosRevista
)