package com.teste.marvelkotlin.model

data class Preco (
    val type : String,
    val price : Float

)