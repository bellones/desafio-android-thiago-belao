package com.teste.marvelkotlin.model

data class Foto (
    val path: String,
    val extension: String
)