package com.teste.marvelkotlin.model

data class Retorno (
    val code: Int,
    val etag: String,
    val data: Dados
)